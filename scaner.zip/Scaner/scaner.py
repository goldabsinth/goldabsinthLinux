import argparse
import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
from threading import Thread
from queue import Queue
import requests
import ipaddress
import os

# Глобальная переменная для хранения результатов сканирования
scan_results = {}

# Сканирование сети
def do_ping_sweep(ip, num_of_host):
    try:
        ipaddress.IPv4Address(ip)  # Проверка корректности формата IP-адреса
    except ipaddress.AddressValueError:
        print("Invalid IP address format")
        return

    ip_parts = ip.split('.')
    network_ip = ip_parts[0] + '.' + ip_parts[1] + '.' + ip_parts[2] + '.'
    scanned_ip = network_ip + str(int(ip_parts[3]) + num_of_host)
    response = os.popen(f'ping -c 2 {scanned_ip}')
    res = response.readlines()
    scan_results[scanned_ip] = res[2]

# Отправка запросов
def sent_http_request(target, method, headers=None, payload=None):
    headers_dict = {}
    if headers:
        for header in headers:
            header_name, header_value = header.split(":")
            headers_dict[header_name.strip()] = header_value.strip()

    if method == "GET":
        response = requests.get(target, headers=headers_dict)
    elif method == "POST":
        response = requests.post(target, headers=headers_dict, data=payload)

    return response

# Обработчик запросов
class RequestHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        # Получение данных из запроса
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length).decode('utf-8')
        parsed_data = json.loads(post_data)

        # Проверка типа запроса
        if self.path == '/sendhttp':
            # Отправка HTTP-запроса и получение ответа
            response = sent_http_request(parsed_data['Target'], parsed_data['Method'],
                                         [f"{parsed_data['Header']}: {parsed_data['Header-value']}"])

            # Отправка ответа пользователю
            self.send_response(response.status_code)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({
                'status_code': response.status_code,
                'headers': dict(response.headers),
                'content': response.text
            }).encode('utf-8'))

        elif self.path == '/scan':
            # Сканирование сети
            ip = parsed_data['target']
            num_of_hosts = int(parsed_data['count'])
            for host_num in range(1, num_of_hosts + 1):
                do_ping_sweep(ip, host_num)

            # Отправка ответа пользователю
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(scan_results).encode('utf-8'))

# Парсеры
parser = argparse.ArgumentParser(description='Network scanner and HTTP request sender')
subparsers = parser.add_subparsers(dest='command')

# Парсер для отправки HTTP-запроса
sendhttp_parser = subparsers.add_parser('sendhttp', help='Send HTTP request')
sendhttp_parser.add_argument('-t', '--target', required=True, help='Target URL')
sendhttp_parser.add_argument('-m', '--method', required=True, help='HTTP method (GET or POST)')
sendhttp_parser.add_argument('-hd', '--headers', nargs='+', metavar=('name', 'value'), help='HTTP headers')

# Парсер для сканирования сети
scan_parser = subparsers.add_parser('scan', help='Scan network')
scan_parser.add_argument('-t', '--target', required=True, help='Target IP address')
scan_parser.add_argument('-c', '--count', type=int, required=True, help='Number of hosts to scan')

parser.add_argument('-p', '--port', type=int, default=3000, help='Port to run the HTTP server on')
args = parser.parse_args()

if args.command == 'sendhttp':
    response = sent_http_request(args.target, args.method, args.headers)
    print(f'Status code: {response.status_code}')
    print(f'Headers: {dict(response.headers)}')
    print(f'Content: {response.text}')
elif args.command == 'scan':
    for host_num in range(1, args.count + 1):
        do_ping_sweep(args.target, host_num)
    print(scan_results)
else:
    # Запуск HTTP-сервера в отдельном потоке
    server_address = ('', args.port)
    httpd = HTTPServer(server_address, RequestHandler)
    print(f"Starting HTTP server on port {args.port}...")
    server_thread = Thread(target=httpd.serve_forever)
    server_thread.daemon = True
    server_thread.start()
    print("HTTP server started.")

    # Ожидание завершения работы сервера
    try:
        server_thread.join()
    except KeyboardInterrupt:
        print("Stopping HTTP server...")
        httpd.shutdown()
        httpd.server_close()
